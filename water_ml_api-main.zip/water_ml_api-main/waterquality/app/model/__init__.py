# ph=7&hardness=264&temperature=76&turbidity=4
# ph=10&hardness=81&temperature=52&turbidity=4

