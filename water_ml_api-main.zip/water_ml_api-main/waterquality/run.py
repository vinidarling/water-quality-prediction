from app import flask_app

flask_app.run(debug=True)
